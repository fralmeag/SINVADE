<div align="center">
<table>
  <tr>
    <td align="center"><img id="Image1" name="Image1" alt="" src="http://nyquist.app/sinvade/imagenes/FotoValoracion.png">
        <img id="Image1" name="Image1" alt="" src="http://nyquist.app/sinvade/imagenes/TextoSinvade.png">
        <img id="Image1" name="Image1" alt="" src="http://nyquist.app/sinvade/imagenes/Logo_U.T.P.png">
    </td>
  </tr>
</table>
</div>
