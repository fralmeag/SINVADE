<div align="center">
  <table>
    <tr>
      <td align="center"><img id="Image2" name="Image2" alt="" src="http://nyquist.app/sinvade/imagenes/image.png">
                         <img id="Image4" name="Image4" alt="" src="http://nyquist.app/sinvade/imagenes/LogoNyquis.jpg"> 
                         <img id="Image3" name="Image3" alt="" src="http://nyquist.app/sinvade/imagenes/CDR-960x1024.jpg">
       </td>
    </tr>
 
    <tr>
      <td colspan="3">
        <p align="center">Desarrollado por el grupo de invertigación Nyquist<br>
        Universidad tecnológica de Pereira<br>
        Copyright &copy; 2023 </p>
      </td>
    </tr>
  </table>
</div>
